<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/assets/logo-CTag5iDh.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Al-Asour Rental Car</title>
    <script type="module" crossorigin src="/assets/index-CHG3ScF3.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-CDW9qA5y.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
